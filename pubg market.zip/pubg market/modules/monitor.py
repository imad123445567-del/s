import asyncio
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict
from pyrogram import Client
from pyrogram.types import Message
import config
from modules.database import Database
from modules.detector import ItemDetector
from modules.pricing import PricingEngine
from utils.frame_extractor import FrameExtractor
from utils.safety import SafetyManager

class MessageMonitor:
    """مراقبة ومعالجة الرسائل في الكروبات والقنوات"""
    
    def __init__(self, db: Database, detector: ItemDetector, pricing: PricingEngine):
        self.db = db
        self.detector = detector
        self.pricing = pricing
        self.frame_extractor = FrameExtractor()
        self.safety = SafetyManager()
        
        self.last_check = {}  # آخر فحص لكل مصدر
        self.processed_messages = set()  # الرسائل المعالجة
    
    async def start_monitoring(self, app: Client):
        """بدء المراقبة المستمرة"""
        while True:
            try:
                sources = self.db.get_all_sources()
                
                for source in sources:
                    chat_id = source['chat_id']
                    
                    # انتظار عشوائي للأمان
                    await self.safety.random_sleep()
                    
                    # معالجة الرسائل الجديدة
                    await self.check_new_messages(app, chat_id)
                
                # انتظار حتى الدورة التالية
                await asyncio.sleep(config.MONITOR_INTERVAL)
                
            except Exception as e:
                print(f"❌ خطأ في المراقبة: {e}")
                await asyncio.sleep(60)
    
    async def check_new_messages(self, app: Client, chat_id: int):
        """فحص الرسائل الجديدة في محادثة"""
        try:
            # الحصول على آخر رسالة معالجة
            last_id = self.last_check.get(chat_id, 0)
            
            # جلب الرسائل الجديدة
            async for message in app.get_chat_history(chat_id, limit=50):
                if message.id <= last_id:
                    break
                
                # معالجة الرسالة
                await self.process_message(message)
                
                # تحديث آخر معالجة
                self.last_check[chat_id] = max(self.last_check.get(chat_id, 0), message.id)
            
            # تحديث قاعدة البيانات
            self.db.update_source_check(chat_id)
            
        except Exception as e:
            print(f"❌ خطأ في فحص {chat_id}: {e}")
    
    async def process_message(self, message: Message):
        """معالجة رسالة واحدة"""
        # تجاهل الرسائل المعالجة سابقاً
        msg_key = f"{message.chat.id}_{message.id}"
        if msg_key in self.processed_messages:
            return
        
        # تجاهل الرسائل القديمة
        if message.date < datetime.now() - timedelta(hours=config.MAX_MESSAGE_AGE_HOURS):
            return
        
        # فحص إذا كانت رسالة بيع
        if not self._is_sale_message(message):
            return
        
        print(f"📨 معالجة رسالة من {message.chat.title}")
        
        # استخراج المعلومات
        price = self._extract_price(message.text or message.caption)
        is_sold = self._is_sold(message.text or message.caption)
        
        detected_items = []
        media_path = None
        
        # معالجة الصور
        if message.photo:
            media_path = await self._download_media(message)
            if media_path:
                detected_items = self.detector.detect_items_in_image(str(media_path))
        
        # معالجة الفيديو
        elif message.video or message.animation:
            media_path = await self._download_media(message)
            if media_path:
                # استخراج الفريمات
                frames = self.frame_extractor.extract_frames(str(media_path))
                detected_items = self.detector.detect_items_in_frames(frames)
        
        # حفظ في قاعدة البيانات
        if detected_items:
            items_data = [(item['item_id'], item['confidence']) for item in detected_items]
            
            account_id = self.db.add_detected_account(
                message_id=message.id,
                chat_id=message.chat.id,
                items=items_data,
                description=message.text or message.caption,
                price=price,
                is_sold=is_sold,
                media_path=str(media_path) if media_path else None
            )
            
            # إضافة أسعار العناصر إذا كان مبيوعاً
            if is_sold and price:
                for item in detected_items:
                    # تقسيم السعر على العناصر
                    item_price = price / len(detected_items)
                    self.db.add_market_price(
                        item['item_id'],
                        item_price,
                        message.chat.id,
                        is_sold=True
                    )
            
            # إرسال إشعار
            await self._send_notification(message, detected_items, price)
        
        # وضع علامة على الرسالة كمعالجة
        self.processed_messages.add(msg_key)
        
        # تنظيف الذاكرة
        if len(self.processed_messages) > 10000:
            self.processed_messages.clear()
    
    async def _download_media(self, message: Message) -> Optional[Path]:
        """تنزيل وسائط الرسالة"""
        try:
            # إنشاء مجلد مؤقت
            temp_dir = config.TEMP_DIR / f"msg_{message.chat.id}_{message.id}"
            temp_dir.mkdir(parents=True, exist_ok=True)
            
            # تنزيل
            file_path = await message.download(file_name=str(temp_dir / "media"))
            
            return Path(file_path) if file_path else None
        except Exception as e:
            print(f"❌ فشل تنزيل الوسائط: {e}")
            return None
    
    def _is_sale_message(self, message: Message) -> bool:
        """فحص إذا كانت رسالة بيع"""
        text = (message.text or message.caption or "").lower()
        
        # تجاهل السبام
        for spam_word in config.SPAM_KEYWORDS:
            if spam_word in text:
                return False
        
        # فحص كلمات البيع
        has_sale_keyword = any(keyword in text for keyword in config.SALE_KEYWORDS)
        
        # يجب أن تحتوي على وسائط
        has_media = message.photo or message.video or message.animation
        
        return has_sale_keyword and has_media
    
    def _extract_price(self, text: str) -> Optional[float]:
        """استخراج السعر من النص"""
        if not text:
            return None
        
        # البحث عن أرقام بجانب كلمات السعر
        patterns = [
            r'(\d+)\s*(?:ريال|ر\.س|SAR)',
            r'(?:السعر|سعر|Price)[\s:]*(\d+)',
            r'(\d+)\s*(?:دولار|USD|\$)',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                try:
                    price = float(match.group(1))
                    if config.MIN_PRICE <= price <= config.MAX_PRICE:
                        return price
                except:
                    pass
        
        return None
    
    def _is_sold(self, text: str) -> bool:
        """فحص إذا كان الحساب مبيوعاً"""
        if not text:
            return False
        
        text = text.lower()
        return any(keyword in text for keyword in config.SOLD_KEYWORDS)
    
    async def _send_notification(self, message: Message, items: List[Dict], price: Optional[float]):
        """إرسال إشعار عند اكتشاف عناصر نادرة"""
        if not config.NOTIFY_ON_RARE:
            return
        
        # فحص إذا كانت العناصر نادرة بما يكفي
        rare_items = [item for item in items if item.get('confidence', 0) >= 0.8]
        
        if not rare_items:
            return
        
        # حساب السعر المتوقع
        pricing_result = self.pricing.estimate_account_price(rare_items)
        
        # تحضير الرسالة
        notification = "🚨 **تنبيه: حساب نادر مكتشف!**\n\n"
        notification += f"📍 **المصدر:** {message.chat.title}\n"
        
        if price:
            notification += f"💰 **السعر المعروض:** {price:.0f} ريال\n"
        
        notification += f"💎 **السعر المتوقع:** {pricing_result['estimated_price']:.0f} ريال\n"
        notification += f"📊 **الثقة:** {pricing_result['confidence']}\n\n"
        
        notification += "🎯 **العناصر المكتشفة:**\n"
        for item in rare_items[:10]:
            notification += f"• {item['item_name']} ({item['confidence']*100:.0f}%)\n"
        
        if len(rare_items) > 10:
            notification += f"... و {len(rare_items) - 10} عنصر آخر\n"
        
        notification += f"\n🔗 [رابط الإعلان](https://t.me/{message.chat.username}/{message.id})"
        
        # إرسال الإشعار (سيتم تنفيذه في NotificationManager)
        print(notification)