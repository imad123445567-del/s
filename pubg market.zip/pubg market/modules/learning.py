import cv2
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
import config
from modules.database import Database
from modules.detector import ItemDetector
from utils.image_processor import ImageProcessor

class LearningSystem:
    """نظام التعلم الذاتي والتحسين المستمر"""
    
    def __init__(self, db: Database, detector: ItemDetector):
        self.db = db
        self.detector = detector
        self.image_processor = ImageProcessor()
        
        # قائمة انتظار للتأكيدات
        self.pending_confirmations = {}
    
    async def process_batch_items_image(self, image_path: str, user_id: int) -> Dict:
        """
        معالجة صورة تحتوي على عدة عناصر نادرة (30-50 عنصر)
        يقوم بتقسيمها وتحليل كل عنصر على حدة
        """
        print(f"🖼️ بدء معالجة صورة مجموعة النوادر...")
        
        # قراءة الصورة
        image = cv2.imread(image_path)
        if image is None:
            return {'success': False, 'error': 'فشل قراءة الصورة'}
        
        # تقسيم الصورة إلى عناصر فردية
        items_crops = self._split_items_grid(image)
        
        print(f"✅ تم تقسيم الصورة إلى {len(items_crops)} عنصر")
        
        # معالجة كل عنصر
        processed_items = []
        new_items = []
        
        for idx, (crop, bbox) in enumerate(items_crops):
            # حفظ الـ crop
            crop_path = config.RARE_ITEMS_DIR / f"batch_{user_id}_{idx}.png"
            cv2.imwrite(str(crop_path), crop)
            
            # محاولة التعرف على العنصر
            match_result = self.detector._match_region_with_items(crop)
            
            if match_result and match_result[0][1] >= config.SIMILARITY_THRESHOLD:
                # عنصر معروف
                item_id, confidence = match_result[0]
                item_info = next(
                    (item for item in self.db.get_all_rare_items() if item['id'] == item_id),
                    None
                )
                
                processed_items.append({
                    'item_id': item_id,
                    'name': item_info['name'] if item_info else 'غير معروف',
                    'confidence': confidence,
                    'status': 'known'
                })
            else:
                # عنصر جديد - يحتاج تأكيد
                new_items.append({
                    'index': idx,
                    'crop_path': str(crop_path),
                    'bbox': bbox
                })
        
        return {
            'success': True,
            'total_items': len(items_crops),
            'known_items': len(processed_items),
            'new_items': len(new_items),
            'processed_items': processed_items,
            'new_items_data': new_items
        }
    
    def _split_items_grid(self, image: np.ndarray) -> List[Tuple[np.ndarray, Tuple]]:
        """
        تقسيم صورة تحتوي على شبكة من العناصر
        يستخدم edge detection لتحديد حدود كل عنصر
        """
        # تحويل لـ grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # تطبيق Gaussian Blur
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        # Edge detection
        edges = cv2.Canny(blurred, 50, 150)
        
        # إيجاد الـ contours
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # فلترة الـ contours وترتيبها
        valid_contours = []
        h, w = image.shape[:2]
        min_area = (w * h) / 100  # على الأقل 1% من الصورة
        
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > min_area:
                x, y, w_c, h_c = cv2.boundingRect(contour)
                
                # فلترة الأشكال غير المعقولة
                aspect_ratio = w_c / h_c if h_c > 0 else 0
                if 0.5 < aspect_ratio < 2.0:  # تقريباً مربع
                    valid_contours.append((x, y, w_c, h_c, area))
        
        # ترتيب من اليسار لليمين، ثم من الأعلى للأسفل
        valid_contours.sort(key=lambda c: (c[1] // 100, c[0]))
        
        # قص كل عنصر
        items_crops = []
        for x, y, w_c, h_c, _ in valid_contours:
            # إضافة padding
            padding = 5
            x1 = max(0, x - padding)
            y1 = max(0, y - padding)
            x2 = min(w, x + w_c + padding)
            y2 = min(h, y + h_c + padding)
            
            crop = image[y1:y2, x1:x2]
            
            if crop.size > 0:
                items_crops.append((crop, (x1, y1, x2, y2)))
        
        # إذا فشل الكشف التلقائي، استخدم تقسيم شبكي
        if len(items_crops) < 10:
            print("⚠️ الكشف التلقائي لم يعطِ نتائج كافية، استخدام التقسيم الشبكي...")
            items_crops = self._grid_split(image)
        
        return items_crops
    
    def _grid_split(self, image: np.ndarray, rows: int = 5, cols: int = 6) -> List[Tuple[np.ndarray, Tuple]]:
        """تقسيم شبكي بسيط (fallback)"""
        h, w = image.shape[:2]
        cell_h = h // rows
        cell_w = w // cols
        
        crops = []
        for i in range(rows):
            for j in range(cols):
                y1 = i * cell_h
                y2 = (i + 1) * cell_h
                x1 = j * cell_w
                x2 = (j + 1) * cell_w
                
                crop = image[y1:y2, x1:x2]
                if crop.size > 0:
                    crops.append((crop, (x1, y1, x2, y2)))
        
        return crops
    
    async def request_confirmation(self, crop_path: str, item_id: Optional[int] = None) -> InlineKeyboardMarkup:
        """
        طلب تأكيد من المستخدم على عنصر
        """
        confirmation_id = f"confirm_{len(self.pending_confirmations)}"
        
        self.pending_confirmations[confirmation_id] = {
            'crop_path': crop_path,
            'item_id': item_id,
            'timestamp': cv2.getTickCount()
        }
        
        if item_id:
            # تأكيد عنصر موجود
            item_info = next(
                (item for item in self.db.get_all_rare_items() if item['id'] == item_id),
                None
            )
            
            text = f"❓ **هل هذا العنصر هو:**\n{item_info['name']}؟"
            
            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("✅ نعم", callback_data=f"confirm_yes_{confirmation_id}"),
                    InlineKeyboardButton("❌ لا", callback_data=f"confirm_no_{confirmation_id}")
                ],
                [
                    InlineKeyboardButton("➕ عنصر جديد", callback_data=f"confirm_new_{confirmation_id}")
                ]
            ])
        else:
            # عنصر جديد تماماً
            text = "❓ **عنصر غير معروف**\n\nهل تريد إضافته؟"
            
            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("➕ نعم، إضافة", callback_data=f"add_new_{confirmation_id}"),
                    InlineKeyboardButton("❌ تجاهل", callback_data=f"ignore_{confirmation_id}")
                ]
            ])
        
        return keyboard, text
    
    async def handle_confirmation(self, callback_data: str, user_response: Dict) -> Dict:
        """معالجة رد المستخدم على التأكيد"""
        parts = callback_data.split('_')
        action = parts[1]
        confirmation_id = '_'.join(parts[2:])
        
        if confirmation_id not in self.pending_confirmations:
            return {'success': False, 'error': 'انتهت صلاحية التأكيد'}
        
        pending = self.pending_confirmations[confirmation_id]
        crop_path = pending['crop_path']
        item_id = pending['item_id']
        
        if action == 'yes':
            # تأكيد صحيح - تحديث الثقة
            self.db.log_user_feedback(item_id, crop_path, 'correct')
            
            # إعادة تدريب الـ detector
            self.detector.add_new_item_template(item_id, crop_path)
            
            del self.pending_confirmations[confirmation_id]
            
            return {
                'success': True,
                'message': '✅ شكراً! تم التأكيد وتحسين الدقة'
            }
        
        elif action == 'no':
            # تأكيد خاطئ
            self.db.log_user_feedback(item_id, crop_path, 'incorrect')
            
            del self.pending_confirmations[confirmation_id]
            
            return {
                'success': True,
                'message': '✅ شكراً! سيتم تحسين الدقة'
            }
        
        elif action == 'new':
            # إنشاء عنصر جديد
            return {
                'success': True,
                'action': 'request_item_details',
                'crop_path': crop_path
            }
        
        elif action == 'ignore':
            # تجاهل
            del self.pending_confirmations[confirmation_id]
            
            return {
                'success': True,
                'message': 'تم التجاهل'
            }
    
    async def add_new_item_interactive(self, crop_path: str, item_details: Dict) -> Dict:
        """إضافة عنصر نادر جديد بشكل تفاعلي"""
        # التحقق من المعلومات المطلوبة
        required_fields = ['name', 'category']
        for field in required_fields:
            if field not in item_details:
                return {
                    'success': False,
                    'error': f'الحقل {field} مطلوب'
                }
        
        # حفظ الصورة في المكان الصحيح
        item_name_clean = item_details['name'].replace(' ', '_')
        final_path = config.RARE_ITEMS_DIR / f"{item_name_clean}.png"
        
        # نسخ الصورة
        import shutil
        shutil.copy(crop_path, final_path)
        
        # إضافة للقاعدة
        item_id = self.db.add_rare_item(
            name=item_details['name'],
            category=item_details['category'],
            name_en=item_details.get('name_en'),
            season=item_details.get('season'),
            rarity_score=item_details.get('rarity_score', 50),
            image_path=str(final_path),
            description=item_details.get('description'),
            confirmed=True
        )
        
        # إضافة للـ detector
        self.detector.add_new_item_template(item_id, str(final_path))
        
        # تسجيل في log التعلم
        self.db.log_user_feedback(item_id, str(final_path), 'new_item')
        
        return {
            'success': True,
            'item_id': item_id,
            'message': f'✅ تم إضافة العنصر: {item_details["name"]}'
        }
    
    def get_learning_stats(self) -> Dict:
        """إحصائيات التعلم"""
        conn = self.db.get_connection()
        
        stats = {}
        
        # إجمالي التصحيحات
        cursor = conn.execute('''
            SELECT 
                user_feedback,
                COUNT(*) as count
            FROM learning_log
            GROUP BY user_feedback
        ''')
        
        feedback_counts = {row['user_feedback']: row['count'] for row in cursor.fetchall()}
        
        stats['total_corrections'] = sum(feedback_counts.values())
        stats['correct_confirmations'] = feedback_counts.get('correct', 0)
        stats['incorrect_detections'] = feedback_counts.get('incorrect', 0)
        stats['new_items_added'] = feedback_counts.get('new_item', 0)
        
        # معدل الدقة
        total = stats['correct_confirmations'] + stats['incorrect_detections']
        stats['accuracy_rate'] = (stats['correct_confirmations'] / total * 100) if total > 0 else 0
        
        conn.close()
        
        return stats