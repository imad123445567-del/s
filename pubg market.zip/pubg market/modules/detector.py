import cv2
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import config
from modules.database import Database

class ItemDetector:
    """كشف العناصر النادرة في الصور والفيديوهات"""
    
    def __init__(self, db: Database):
        self.db = db
        self.confidence_threshold = config.CONFIDENCE_THRESHOLD
        self.similarity_threshold = config.SIMILARITY_THRESHOLD
        
        # تحميل العناصر النادرة المحفوظة
        self.rare_items = self._load_rare_items()
        
        # SIFT detector للمطابقة المتقدمة
        self.sift = cv2.SIFT_create()
        self.bf_matcher = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
    
    def _load_rare_items(self) -> Dict[int, Dict]:
        """تحميل العناصر النادرة من قاعدة البيانات"""
        items = self.db.get_all_rare_items()
        
        rare_items_dict = {}
        for item in items:
            if item['image_path'] and Path(item['image_path']).exists():
                # تحميل الصورة
                img = cv2.imread(item['image_path'])
                if img is not None:
                    # استخراج features
                    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
                    keypoints, descriptors = self.sift.detectAndCompute(gray, None)
                    
                    rare_items_dict[item['id']] = {
                        'info': item,
                        'image': img,
                        'keypoints': keypoints,
                        'descriptors': descriptors
                    }
        
        print(f"✅ تم تحميل {len(rare_items_dict)} عنصر نادر")
        return rare_items_dict
    
    def detect_items_in_image(self, image_path: str) -> List[Dict]:
        """كشف العناصر النادرة في صورة"""
        # قراءة الصورة
        img = cv2.imread(image_path)
        if img is None:
            return []
        
        # تقسيم الصورة لمناطق
        regions = self._split_image_to_regions(img)
        
        detected_items = []
        
        # فحص كل منطقة
        for region_idx, (region_img, bbox) in enumerate(regions):
            # مطابقة مع العناصر النادرة
            matches = self._match_region_with_items(region_img)
            
            for item_id, confidence in matches:
                if confidence >= self.confidence_threshold:
                    detected_items.append({
                        'item_id': item_id,
                        'item_name': self.rare_items[item_id]['info']['name'],
                        'confidence': confidence,
                        'region': region_idx,
                        'bbox': bbox
                    })
        
        # إزالة التكرارات (نفس العنصر في مناطق متعددة)
        detected_items = self._remove_duplicates(detected_items)
        
        return detected_items
    
    def detect_items_in_frames(self, frames: List[np.ndarray]) -> List[Dict]:
        """كشف العناصر في عدة فريمات ودمج النتائج"""
        all_detections = {}
        
        for frame_idx, frame in enumerate(frames):
            # حفظ الفريم مؤقتاً
            temp_path = config.TEMP_DIR / f"temp_frame_{frame_idx}.jpg"
            cv2.imwrite(str(temp_path), frame)
            
            # كشف العناصر
            detections = self.detect_items_in_image(str(temp_path))
            
            # دمج النتائج
            for det in detections:
                item_id = det['item_id']
                if item_id in all_detections:
                    # زيادة الثقة
                    all_detections[item_id]['confidence'] = min(
                        1.0,
                        all_detections[item_id]['confidence'] + det['confidence'] * 0.1
                    )
                    all_detections[item_id]['frame_count'] += 1
                else:
                    all_detections[item_id] = {
                        'item_id': item_id,
                        'item_name': det['item_name'],
                        'confidence': det['confidence'],
                        'frame_count': 1
                    }
            
            # حذف الملف المؤقت
            temp_path.unlink(missing_ok=True)
        
        # ترتيب حسب الثقة
        results = sorted(all_detections.values(), key=lambda x: x['confidence'], reverse=True)
        return results
    
    def _split_image_to_regions(self, img: np.ndarray, grid_size: int = 3) -> List[Tuple[np.ndarray, Tuple]]:
        """تقسيم الصورة إلى مناطق متداخلة"""
        h, w = img.shape[:2]
        regions = []
        
        # تقسيم شبكي
        step_h = h // grid_size
        step_w = w // grid_size
        
        for i in range(grid_size):
            for j in range(grid_size):
                y1 = i * step_h
                y2 = min((i + 1) * step_h + step_h // 2, h)
                x1 = j * step_w
                x2 = min((j + 1) * step_w + step_w // 2, w)
                
                region = img[y1:y2, x1:x2]
                if region.size > 0:
                    regions.append((region, (x1, y1, x2, y2)))
        
        # إضافة الصورة كاملة
        regions.append((img, (0, 0, w, h)))
        
        return regions
    
    def _match_region_with_items(self, region: np.ndarray) -> List[Tuple[int, float]]:
        """مطابقة منطقة مع العناصر النادرة"""
        gray_region = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
        kp_region, des_region = self.sift.detectAndCompute(gray_region, None)
        
        if des_region is None:
            return []
        
        matches_results = []
        
        for item_id, item_data in self.rare_items.items():
            if item_data['descriptors'] is None:
                continue
            
            # مطابقة features
            matches = self.bf_matcher.knnMatch(des_region, item_data['descriptors'], k=2)
            
            # Lowe's ratio test
            good_matches = []
            for m_n in matches:
                if len(m_n) == 2:
                    m, n = m_n
                    if m.distance < 0.75 * n.distance:
                        good_matches.append(m)
            
            # حساب الثقة
            if len(good_matches) > 4:  # على الأقل 4 نقاط مطابقة
                confidence = min(1.0, len(good_matches) / 20.0)
                
                # مطابقة إضافية باستخدام Template Matching
                template_score = self._template_matching(region, item_data['image'])
                
                # الثقة النهائية
                final_confidence = (confidence * 0.7 + template_score * 0.3)
                
                if final_confidence >= self.similarity_threshold:
                    matches_results.append((item_id, final_confidence))
        
        return sorted(matches_results, key=lambda x: x[1], reverse=True)
    
    def _template_matching(self, region: np.ndarray, template: np.ndarray) -> float:
        """مطابقة بسيطة باستخدام Template Matching"""
        try:
            # تحجيم template لتناسب المنطقة
            h, w = region.shape[:2]
            t_h, t_w = template.shape[:2]
            
            if t_h > h or t_w > w:
                scale = min(h / t_h, w / t_w) * 0.8
                new_size = (int(t_w * scale), int(t_h * scale))
                template = cv2.resize(template, new_size)
            
            # تحويل لـ grayscale
            gray_region = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
            gray_template = cv2.cvtColor(template, cv2.COLOR_BGR2GRAY)
            
            # مطابقة
            result = cv2.matchTemplate(gray_region, gray_template, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, _ = cv2.minMaxLoc(result)
            
            return max(0, max_val)
        except:
            return 0.0
    
    def _remove_duplicates(self, detections: List[Dict]) -> List[Dict]:
        """إزالة العناصر المكررة"""
        seen = set()
        unique = []
        
        for det in sorted(detections, key=lambda x: x['confidence'], reverse=True):
            item_id = det['item_id']
            if item_id not in seen:
                seen.add(item_id)
                unique.append(det)
        
        return unique
    
    def add_new_item_template(self, item_id: int, image_path: str):
        """إضافة عنصر نادر جديد"""
        img = cv2.imread(image_path)
        if img is None:
            return False
        
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        keypoints, descriptors = self.sift.detectAndCompute(gray, None)
        
        item_info = self.db.get_all_rare_items()
        item_info = next((i for i in item_info if i['id'] == item_id), None)
        
        if item_info:
            self.rare_items[item_id] = {
                'info': item_info,
                'image': img,
                'keypoints': keypoints,
                'descriptors': descriptors
            }
            return True
        
        return False
    
    def reload_items(self):
        """إعادة تحميل العناصر النادرة"""
        self.rare_items = self._load_rare_items()