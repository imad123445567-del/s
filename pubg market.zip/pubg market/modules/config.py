import os
from pathlib import Path

# ==================== Telegram Config ====================
API_ID = "YOUR_API_ID"  # احصل عليه من my.telegram.org
API_HASH = "YOUR_API_HASH"
PHONE_NUMBER = "YOUR_PHONE_NUMBER"  # +966xxxxxxxxx
SESSION_NAME = "pubg_analyzer_session"

# ==================== Paths ====================
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = DATA_DIR / "database.db"
RARE_ITEMS_DIR = DATA_DIR / "rare_items"
BACKUPS_DIR = DATA_DIR / "backups"
TEMP_DIR = DATA_DIR / "temp"

# إنشاء المجلدات إذا لم تكن موجودة
for directory in [DATA_DIR, RARE_ITEMS_DIR, BACKUPS_DIR, TEMP_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# ==================== Safety Settings ====================
# حماية الحساب من الحظر
MIN_SLEEP = 2  # أقل وقت انتظار (ثانية)
MAX_SLEEP = 5  # أقصى وقت انتظار (ثانية)
MAX_MESSAGES_PER_MINUTE = 20  # حد الرسائل في الدقيقة
FLOOD_SLEEP_THRESHOLD = 60  # الانتظار عند Flood

# ==================== Monitoring Settings ====================
MONITOR_INTERVAL = 30  # التحقق كل 30 ثانية
MAX_MESSAGE_AGE_HOURS = 24  # تجاهل الرسائل الأقدم من 24 ساعة
PROCESS_MEDIA_ONLY = True  # معالجة الرسائل التي تحتوي على صور/فيديو فقط

# ==================== Video Processing ====================
FRAME_INTERVAL = 2  # استخراج فريم كل 2 ثانية
MAX_VIDEO_DURATION = 300  # معالجة فيديوهات حتى 5 دقائق
VIDEO_QUALITY = "medium"  # low, medium, high
MAX_FRAMES_PER_VIDEO = 30  # حد أقصى للفريمات

# ==================== Item Detection ====================
CONFIDENCE_THRESHOLD = 0.75  # حد الثقة لكشف العناصر
MIN_ITEM_SIZE = 50  # أقل حجم للعنصر بالبكسل
SIMILARITY_THRESHOLD = 0.85  # نسبة التشابه للمطابقة

# ==================== Item Categories ====================
ITEM_CATEGORIES = {
    "outfit": "لبسات",
    "backpack": "جنط",
    "helmet": "خوذ",
    "shoes": "أحذية",
    "shirt": "تيشيرتات",
    "tire": "إطارات",
    "skin": "سكنات",
    "other": "نوادر أخرى"
}

# ==================== Pricing Settings ====================
MIN_PRICE = 10  # أقل سعر معقول
MAX_PRICE = 100000  # أقصى سعر معقول
PRICE_CONFIDENCE_MIN_SAMPLES = 5  # عدد العينات للثقة بالسعر
OUTLIER_THRESHOLD = 2.5  # معامل الانحراف المعياري لتجاهل القيم الشاذة

# ==================== Notifications ====================
NOTIFY_ON_RARE = True  # إشعار عند ظهور عنصر نادر
NOTIFY_ON_GOOD_PRICE = True  # إشعار عند سعر جيد
MIN_RARITY_SCORE = 80  # أقل درجة ندرة للإشعار (من 100)
GOOD_PRICE_DISCOUNT = 0.20  # 20% أقل من متوسط السوق

# ==================== Learning Settings ====================
AUTO_LEARN = True  # التعلم التلقائي
REQUIRE_CONFIRMATION = True  # طلب تأكيد قبل حفظ عنصر جديد
MIN_DETECTIONS_TO_TRUST = 3  # عدد الكشف للثقة التلقائية

# ==================== Database ====================
BACKUP_INTERVAL_HOURS = 24  # نسخ احتياطي كل 24 ساعة
MAX_BACKUPS = 7  # الاحتفاظ بآخر 7 نسخ

# ==================== Keywords للفلترة ====================
SPAM_KEYWORDS = [
    "اشترك", "subscribe", "متابعة", "follow",
    "لايك", "like", "شير", "share"
]

SALE_KEYWORDS = [
    "للبيع", "بيع", "سعر", "ريال", "دولار", "$",
    "حساب", "اكونت", "account", "ببجي", "pubg"
]

SOLD_KEYWORDS = [
    "مبيوع", "بيع", "sold", "تم البيع"
]

# ==================== UI Settings ====================
UI_LANGUAGE = "ar"  # العربية
ENABLE_EMOJI = True  # استخدام الإيموجي
ITEMS_PER_PAGE = 10  # عناصر في كل صفحة

# ==================== Debug ====================
DEBUG_MODE = False  # وضع التطوير
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
SAVE_PROCESSED_IMAGES = True  # حفظ الصور المعالجة للمراجعة