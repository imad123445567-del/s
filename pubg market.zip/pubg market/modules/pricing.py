import numpy as np
from typing import List, Dict, Optional
import config
from modules.database import Database

class PricingEngine:
    """محرك التسعير الواقعي لحسابات PUBG"""
    
    def __init__(self, db: Database):
        self.db = db
        self.min_samples = config.PRICE_CONFIDENCE_MIN_SAMPLES
        self.outlier_threshold = config.OUTLIER_THRESHOLD
    
    def estimate_account_price(self, items: List[Dict], account_info: Optional[Dict] = None) -> Dict:
        """تقدير سعر حساب بناءً على العناصر النادرة"""
        if not items:
            return {
                'estimated_price': 0,
                'confidence': 'low',
                'reasoning': 'لا توجد عناصر نادرة مكتشفة'
            }
        
        total_value = 0
        item_values = []
        reasoning_parts = []
        
        for item in items:
            item_id = item['item_id']
            item_confidence = item.get('confidence', 0.8)
            
            # الحصول على سعر العنصر
            price_stats = self.get_item_value(item_id)
            
            if price_stats['has_data']:
                item_value = price_stats['avg_price'] * item_confidence
                total_value += item_value
                item_values.append({
                    'name': item.get('item_name', 'عنصر'),
                    'value': price_stats['avg_price'],
                    'adjusted_value': item_value,
                    'confidence': item_confidence
                })
                
                reasoning_parts.append(
                    f"• {item.get('item_name')}: {price_stats['avg_price']:.0f} ريال "
                    f"(ثقة: {item_confidence*100:.0f}%)"
                )
            else:
                # تقدير تقريبي
                estimated = self._estimate_unknown_item(item)
                total_value += estimated
                reasoning_parts.append(
                    f"• {item.get('item_name')}: ~{estimated:.0f} ريال (تقدير)"
                )
        
        # تطبيق عوامل إضافية
        bonus_multiplier = self._calculate_synergy_bonus(items)
        total_value *= bonus_multiplier
        
        if bonus_multiplier > 1.0:
            reasoning_parts.append(
                f"\n🎁 مكافأة التنوع: +{(bonus_multiplier-1)*100:.0f}%"
            )
        
        # تحديد مستوى الثقة
        confidence_level = self._calculate_confidence(items, item_values)
        
        # النطاق السعري
        price_range = self._calculate_price_range(total_value, confidence_level)
        
        return {
            'estimated_price': round(total_value),
            'price_range': price_range,
            'confidence': confidence_level,
            'item_breakdown': item_values,
            'reasoning': '\n'.join(reasoning_parts),
            'market_comparison': self._get_market_comparison(total_value)
        }
    
    def get_item_value(self, item_id: int, only_sold: bool = True) -> Dict:
        """الحصول على قيمة عنصر نادر من السوق"""
        stats = self.db.get_item_price_stats(item_id, only_sold)
        
        if stats['count'] < self.min_samples:
            return {
                'has_data': False,
                'avg_price': 0,
                'sample_count': stats['count']
            }
        
        # إزالة القيم الشاذة
        if 'prices' in stats:
            prices = np.array(stats['prices'])
            cleaned_prices = self._remove_outliers(prices)
            
            return {
                'has_data': True,
                'avg_price': np.mean(cleaned_prices),
                'median_price': np.median(cleaned_prices),
                'min_price': np.min(cleaned_prices),
                'max_price': np.max(cleaned_prices),
                'std_dev': np.std(cleaned_prices),
                'sample_count': len(cleaned_prices),
                'confidence': self._price_confidence(len(cleaned_prices))
            }
        
        return {
            'has_data': True,
            'avg_price': stats['avg_price'],
            'min_price': stats['min_price'],
            'max_price': stats['max_price'],
            'sample_count': stats['count'],
            'confidence': self._price_confidence(stats['count'])
        }
    
    def _remove_outliers(self, prices: np.ndarray) -> np.ndarray:
        """إزالة القيم الشاذة باستخدام IQR"""
        if len(prices) < 4:
            return prices
        
        q1 = np.percentile(prices, 25)
        q3 = np.percentile(prices, 75)
        iqr = q3 - q1
        
        lower_bound = q1 - (self.outlier_threshold * iqr)
        upper_bound = q3 + (self.outlier_threshold * iqr)
        
        return prices[(prices >= lower_bound) & (prices <= upper_bound)]
    
    def _estimate_unknown_item(self, item: Dict) -> float:
        """تقدير سعر عنصر غير معروف"""
        # سعر افتراضي حسب الفئة
        category = item.get('category', 'other')
        base_prices = {
            'outfit': 300,
            'backpack': 200,
            'helmet': 150,
            'shoes': 100,
            'shirt': 80,
            'tire': 50,
            'skin': 250,
            'other': 100
        }
        
        base = base_prices.get(category, 100)
        
        # تعديل حسب الندرة
        rarity_score = item.get('rarity_score', 50)
        rarity_multiplier = 1 + (rarity_score / 100)
        
        return base * rarity_multiplier
    
    def _calculate_synergy_bonus(self, items: List[Dict]) -> float:
        """حساب مكافأة التنوع (حسابات بعناصر متنوعة أغلى)"""
        if len(items) <= 1:
            return 1.0
        
        # عدد الفئات المختلفة
        categories = set(item.get('category', 'other') for item in items)
        category_bonus = 1 + (len(categories) * 0.05)  # +5% لكل فئة
        
        # عدد العناصر
        count_bonus = 1 + (min(len(items), 10) * 0.02)  # +2% لكل عنصر (حد أقصى 10)
        
        return min(category_bonus * count_bonus, 1.5)  # حد أقصى +50%
    
    def _calculate_confidence(self, items: List[Dict], item_values: List[Dict]) -> str:
        """حساب مستوى الثقة في التقدير"""
        if not item_values:
            return 'low'
        
        # متوسط الثقة
        avg_confidence = np.mean([iv.get('confidence', 0.5) for iv in item_values])
        
        # عدد العناصر المؤكدة
        confirmed_count = sum(1 for iv in item_values if iv.get('confidence', 0) > 0.8)
        confirmed_ratio = confirmed_count / len(items) if items else 0
        
        if avg_confidence > 0.8 and confirmed_ratio > 0.7:
            return 'high'
        elif avg_confidence > 0.6 and confirmed_ratio > 0.5:
            return 'medium'
        else:
            return 'low'
    
    def _price_confidence(self, sample_count: int) -> str:
        """ثقة السعر حسب عدد العينات"""
        if sample_count >= 20:
            return 'high'
        elif sample_count >= 10:
            return 'medium'
        elif sample_count >= 5:
            return 'low'
        else:
            return 'very_low'
    
    def _calculate_price_range(self, estimated_price: float, confidence: str) -> Dict:
        """حساب نطاق السعر المتوقع"""
        variance_map = {
            'high': 0.10,    # ±10%
            'medium': 0.20,  # ±20%
            'low': 0.30      # ±30%
        }
        
        variance = variance_map.get(confidence, 0.30)
        
        return {
            'min': round(estimated_price * (1 - variance)),
            'max': round(estimated_price * (1 + variance))
        }
    
    def _get_market_comparison(self, price: float) -> str:
        """مقارنة مع أسعار السوق"""
        # الحصول على إحصائيات السوق العامة
        all_accounts = self.db.get_connection().execute('''
            SELECT AVG(price) as avg, MIN(price) as min, MAX(price) as max
            FROM detected_accounts
            WHERE price IS NOT NULL AND is_sold = 1
        ''').fetchone()
        
        if all_accounts and all_accounts['avg']:
            avg_market = all_accounts['avg']
            
            if price < avg_market * 0.7:
                return 'أقل من المتوسط بكثير'
            elif price < avg_market * 0.9:
                return 'أقل من المتوسط'
            elif price < avg_market * 1.1:
                return 'قريب من المتوسط'
            elif price < avg_market * 1.3:
                return 'أعلى من المتوسط'
            else:
                return 'أعلى من المتوسط بكثير'
        
        return 'لا توجد بيانات كافية للمقارنة'
    
    def analyze_market_trends(self, item_id: Optional[int] = None, days: int = 30) -> Dict:
        """تحليل اتجاهات السوق"""
        conn = self.db.get_connection()
        
        query = '''
            SELECT 
                DATE(date_recorded) as date,
                AVG(price) as avg_price,
                COUNT(*) as count
            FROM market_prices
            WHERE date_recorded >= datetime('now', '-{} days')
        '''.format(days)
        
        if item_id:
            query += f' AND item_id = {item_id}'
        
        query += ' GROUP BY DATE(date_recorded) ORDER BY date'
        
        cursor = conn.execute(query)
        data = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        if not data:
            return {'trend': 'no_data', 'data': []}
        
        # حساب الاتجاه
        prices = [d['avg_price'] for d in data]
        
        if len(prices) > 1:
            trend = 'stable'
            first_half = np.mean(prices[:len(prices)//2])
            second_half = np.mean(prices[len(prices)//2:])
            
            change = (second_half - first_half) / first_half * 100
            
            if change > 10:
                trend = 'rising'
            elif change < -10:
                trend = 'falling'
        else:
            trend = 'insufficient_data'
        
        return {
            'trend': trend,
            'data': data,
            'avg_price': np.mean(prices),
            'change_percent': change if len(prices) > 1 else 0
        }
    
    def find_good_deals(self, max_results: int = 10) -> List[Dict]:
        """البحث عن صفقات جيدة (أسعار أقل من المتوسط)"""
        conn = self.db.get_connection()
        
        query = '''
            SELECT 
                da.*,
                GROUP_CONCAT(ri.name) as items
            FROM detected_accounts da
            LEFT JOIN account_items ai ON da.id = ai.account_id
            LEFT JOIN rare_items ri ON ai.item_id = ri.id
            WHERE da.price IS NOT NULL 
            AND da.is_sold = 0
            GROUP BY da.id
            ORDER BY da.detected_date DESC
            LIMIT ?
        '''
        
        cursor = conn.execute(query, (max_results * 2,))
        accounts = [dict(row) for row in cursor.fetchall()]
        conn.close()
        
        good_deals = []
        
        for acc in accounts:
            # حساب السعر المتوقع
            items_list = acc['items'].split(',') if acc['items'] else []
            # هنا يمكن إضافة منطق أكثر تعقيدًا
            
            if len(good_deals) < max_results:
                good_deals.append(acc)
        
        return good_deals