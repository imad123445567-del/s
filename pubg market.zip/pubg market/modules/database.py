import sqlite3
import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import config

class Database:
    def __init__(self):
        self.db_path = config.DB_PATH
        self.init_database()
    
    def get_connection(self):
        """إنشاء اتصال بقاعدة البيانات"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn
    
    def init_database(self):
        """إنشاء جداول قاعدة البيانات"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # جدول المصادر (الكروبات والقنوات)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sources (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chat_id INTEGER UNIQUE NOT NULL,
                chat_title TEXT,
                chat_type TEXT CHECK(chat_type IN ('group', 'channel', 'store_channel')),
                is_trusted BOOLEAN DEFAULT 0,
                added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_checked TIMESTAMP,
                total_messages_processed INTEGER DEFAULT 0
            )
        ''')
        
        # جدول العناصر النادرة
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rare_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                name_en TEXT,
                category TEXT NOT NULL,
                season TEXT,
                rarity_score INTEGER DEFAULT 50,
                image_path TEXT,
                description TEXT,
                added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                detection_count INTEGER DEFAULT 0,
                last_detected TIMESTAMP,
                confirmed BOOLEAN DEFAULT 0,
                metadata TEXT
            )
        ''')
        
        # جدول الإعلانات المكتشفة
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS detected_accounts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id INTEGER,
                chat_id INTEGER,
                account_description TEXT,
                price REAL,
                currency TEXT DEFAULT 'SAR',
                is_sold BOOLEAN DEFAULT 0,
                detected_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                media_path TEXT,
                FOREIGN KEY (chat_id) REFERENCES sources(chat_id)
            )
        ''')
        
        # جدول العلاقة بين الحسابات والعناصر النادرة
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS account_items (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id INTEGER,
                item_id INTEGER,
                confidence REAL DEFAULT 0.0,
                position_in_media TEXT,
                FOREIGN KEY (account_id) REFERENCES detected_accounts(id),
                FOREIGN KEY (item_id) REFERENCES rare_items(id),
                UNIQUE(account_id, item_id)
            )
        ''')
        
        # جدول أسعار السوق
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS market_prices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER,
                price REAL NOT NULL,
                currency TEXT DEFAULT 'SAR',
                source_chat_id INTEGER,
                is_sold BOOLEAN DEFAULT 0,
                date_recorded TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES rare_items(id),
                FOREIGN KEY (source_chat_id) REFERENCES sources(chat_id)
            )
        ''')
        
        # جدول التعلم والتصحيحات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS learning_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                item_id INTEGER,
                image_path TEXT,
                user_feedback TEXT CHECK(user_feedback IN ('correct', 'incorrect', 'new_item')),
                feedback_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                notes TEXT,
                FOREIGN KEY (item_id) REFERENCES rare_items(id)
            )
        ''')
        
        # جدول الإعدادات
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # إنشاء Indexes للأداء
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_sources_chat_id ON sources(chat_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_items_category ON rare_items(category)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_accounts_chat ON detected_accounts(chat_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_prices_item ON market_prices(item_id)')
        
        conn.commit()
        conn.close()
    
    # ==================== إدارة المصادر ====================
    
    def add_source(self, chat_id: int, chat_title: str, chat_type: str, is_trusted: bool = False) -> bool:
        """إضافة مصدر جديد"""
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO sources (chat_id, chat_title, chat_type, is_trusted)
                VALUES (?, ?, ?, ?)
            ''', (chat_id, chat_title, chat_type, is_trusted))
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    def remove_source(self, chat_id: int) -> bool:
        """حذف مصدر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM sources WHERE chat_id = ?', (chat_id,))
        deleted = cursor.rowcount > 0
        conn.commit()
        conn.close()
        return deleted
    
    def get_all_sources(self) -> List[Dict]:
        """الحصول على جميع المصادر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM sources ORDER BY added_date DESC')
        sources = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return sources
    
    def update_source_check(self, chat_id: int):
        """تحديث آخر فحص للمصدر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE sources 
            SET last_checked = CURRENT_TIMESTAMP,
                total_messages_processed = total_messages_processed + 1
            WHERE chat_id = ?
        ''', (chat_id,))
        conn.commit()
        conn.close()
    
    # ==================== إدارة العناصر النادرة ====================
    
    def add_rare_item(self, name: str, category: str, **kwargs) -> int:
        """إضافة عنصر نادر جديد"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO rare_items (name, category, name_en, season, rarity_score, 
                                   image_path, description, confirmed, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            name,
            category,
            kwargs.get('name_en'),
            kwargs.get('season'),
            kwargs.get('rarity_score', 50),
            kwargs.get('image_path'),
            kwargs.get('description'),
            kwargs.get('confirmed', False),
            json.dumps(kwargs.get('metadata', {}))
        ))
        
        item_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return item_id
    
    def get_all_rare_items(self, category: Optional[str] = None) -> List[Dict]:
        """الحصول على جميع العناصر النادرة"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        if category:
            cursor.execute('SELECT * FROM rare_items WHERE category = ? ORDER BY rarity_score DESC', (category,))
        else:
            cursor.execute('SELECT * FROM rare_items ORDER BY rarity_score DESC')
        
        items = []
        for row in cursor.fetchall():
            item = dict(row)
            if item['metadata']:
                item['metadata'] = json.loads(item['metadata'])
            items.append(item)
        
        conn.close()
        return items
    
    def update_item_detection(self, item_id: int):
        """تحديث عداد الكشف للعنصر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE rare_items 
            SET detection_count = detection_count + 1,
                last_detected = CURRENT_TIMESTAMP
            WHERE id = ?
        ''', (item_id,))
        conn.commit()
        conn.close()
    
    # ==================== إدارة الحسابات المكتشفة ====================
    
    def add_detected_account(self, message_id: int, chat_id: int, 
                            items: List[Tuple[int, float]], **kwargs) -> int:
        """إضافة حساب مكتشف مع العناصر النادرة"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # حفظ الحساب
        cursor.execute('''
            INSERT INTO detected_accounts 
            (message_id, chat_id, account_description, price, currency, is_sold, media_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (
            message_id,
            chat_id,
            kwargs.get('description'),
            kwargs.get('price'),
            kwargs.get('currency', 'SAR'),
            kwargs.get('is_sold', False),
            kwargs.get('media_path')
        ))
        
        account_id = cursor.lastrowid
        
        # حفظ العناصر المكتشفة
        for item_id, confidence in items:
            cursor.execute('''
                INSERT INTO account_items (account_id, item_id, confidence)
                VALUES (?, ?, ?)
            ''', (account_id, item_id, confidence))
            
            # تحديث عداد الكشف
            cursor.execute('''
                UPDATE rare_items 
                SET detection_count = detection_count + 1,
                    last_detected = CURRENT_TIMESTAMP
                WHERE id = ?
            ''', (item_id,))
        
        conn.commit()
        conn.close()
        return account_id
    
    # ==================== إدارة الأسعار ====================
    
    def add_market_price(self, item_id: int, price: float, source_chat_id: int, is_sold: bool = False):
        """إضافة سعر في السوق"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO market_prices (item_id, price, source_chat_id, is_sold)
            VALUES (?, ?, ?, ?)
        ''', (item_id, price, source_chat_id, is_sold))
        conn.commit()
        conn.close()
    
    def get_item_price_stats(self, item_id: int, only_sold: bool = True) -> Dict:
        """الحصول على إحصائيات الأسعار لعنصر"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        query = '''
            SELECT 
                COUNT(*) as count,
                AVG(price) as avg_price,
                MIN(price) as min_price,
                MAX(price) as max_price,
                GROUP_CONCAT(price) as all_prices
            FROM market_prices
            WHERE item_id = ?
        '''
        
        if only_sold:
            query += ' AND is_sold = 1'
        
        cursor.execute(query, (item_id,))
        result = dict(cursor.fetchone())
        conn.close()
        
        if result['all_prices']:
            prices = [float(p) for p in result['all_prices'].split(',')]
            result['prices'] = prices
        
        return result
    
    # ==================== التعلم ====================
    
    def log_user_feedback(self, item_id: int, image_path: str, feedback: str, notes: str = None):
        """تسجيل ملاحظات المستخدم"""
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO learning_log (item_id, image_path, user_feedback, notes)
            VALUES (?, ?, ?, ?)
        ''', (item_id, image_path, feedback, notes))
        
        # إذا كان التأكيد صحيحًا، نضع علامة التأكيد
        if feedback == 'correct':
            cursor.execute('UPDATE rare_items SET confirmed = 1 WHERE id = ?', (item_id,))
        
        conn.commit()
        conn.close()
    
    # ==================== الإحصائيات ====================
    
    def get_market_stats(self) -> Dict:
        """إحصائيات السوق العامة"""
        conn = self.get_connection()
        cursor = conn.cursor()
        
        stats = {}
        
        # إجمالي العناصر
        cursor.execute('SELECT COUNT(*) as total FROM rare_items')
        stats['total_items'] = cursor.fetchone()['total']
        
        # إجمالي الحسابات المكتشفة
        cursor.execute('SELECT COUNT(*) as total FROM detected_accounts')
        stats['total_accounts'] = cursor.fetchone()['total']
        
        # الحسابات المبيوعة
        cursor.execute('SELECT COUNT(*) as total FROM detected_accounts WHERE is_sold = 1')
        stats['sold_accounts'] = cursor.fetchone()['total']
        
        # أكثر العناصر ظهورًا
        cursor.execute('''
            SELECT name, detection_count 
            FROM rare_items 
            ORDER BY detection_count DESC 
            LIMIT 10
        ''')
        stats['top_items'] = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
        return stats
    
    # ==================== النسخ الاحتياطي ====================
    
    def create_backup(self) -> Path:
        """إنشاء نسخة احتياطية"""
        from shutil import copy2
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        backup_path = config.BACKUPS_DIR / f"backup_{timestamp}.db"
        copy2(self.db_path, backup_path)
        
        # حذف النسخ القديمة
        backups = sorted(config.BACKUPS_DIR.glob("backup_*.db"))
        if len(backups) > config.MAX_BACKUPS:
            for old_backup in backups[:-config.MAX_BACKUPS]:
                old_backup.unlink()
        
        return backup_path