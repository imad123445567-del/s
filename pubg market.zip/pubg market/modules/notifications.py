from pyrogram import Client
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from typing import List, Dict, Optional
import config

class NotificationManager:
    """إدارة وإرسال الإشعارات الذكية"""
    
    def __init__(self, app: Client):
        self.app = app
        self.sent_notifications = set()  # لتجنب التكرار
    
    async def notify_rare_account(self, 
                                  items: List[Dict], 
                                  price: Optional[float],
                                  estimated_price: float,
                                  source_name: str,
                                  message_link: str):
        """
        إشعار عند اكتشاف حساب نادر
        """
        if not config.NOTIFY_ON_RARE:
            return
        
        # فحص التكرار
        notification_id = f"{source_name}_{price}_{len(items)}"
        if notification_id in self.sent_notifications:
            return
        
        # تحضير النص
        text = "🚨 **تنبيه: حساب نادر مكتشف!**\n\n"
        text += f"📍 **المصدر:** {source_name}\n"
        
        if price:
            text += f"💰 **السعر المعروض:** {price:.0f} ريال\n"
            
            # تحليل السعر
            diff = estimated_price - price
            if diff > 0:
                discount_percent = (diff / estimated_price) * 100
                text += f"💎 **السعر المتوقع:** {estimated_price:.0f} ريال\n"
                text += f"🎁 **توفير:** {diff:.0f} ريال ({discount_percent:.0f}% خصم) ✅\n"
            else:
                text += f"💎 **السعر المتوقع:** {estimated_price:.0f} ريال\n"
                text += f"⚠️ **السعر أعلى من المتوقع**\n"
        else:
            text += f"💎 **السعر المتوقع:** {estimated_price:.0f} ريال\n"
        
        text += f"\n🎯 **العناصر النادرة المكتشفة ({len(items)}):**\n"
        
        for i, item in enumerate(items[:10], 1):
            confidence = item.get('confidence', 0) * 100
            rarity_emoji = self._get_rarity_emoji(confidence)
            text += f"{rarity_emoji} {item['item_name']} ({confidence:.0f}%)\n"
        
        if len(items) > 10:
            text += f"\n... و **{len(items) - 10}** عنصر نادر آخر 🔥\n"
        
        # زر الانتقال للإعلان
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 عرض الإعلان", url=message_link)],
            [InlineKeyboardButton("✅ تم المعاينة", callback_data=f"dismiss_{notification_id}")]
        ])
        
        # إرسال
        try:
            await self.app.send_message(
                "me",
                text,
                reply_markup=keyboard,
                disable_web_page_preview=True
            )
            
            self.sent_notifications.add(notification_id)
            
        except Exception as e:
            print(f"❌ فشل إرسال الإشعار: {e}")
    
    async def notify_good_price(self, 
                               item_name: str,
                               current_price: float,
                               avg_price: float,
                               source_name: str,
                               message_link: str):
        """
        إشعار عند ظهور سعر جيد لعنصر
        """
        if not config.NOTIFY_ON_GOOD_PRICE:
            return
        
        discount_percent = ((avg_price - current_price) / avg_price) * 100
        
        if discount_percent < config.GOOD_PRICE_DISCOUNT * 100:
            return  # ليس خصم كبير
        
        text = "💰 **فرصة سعر ممتاز!**\n\n"
        text += f"🎯 **العنصر:** {item_name}\n"
        text += f"💵 **السعر الحالي:** {current_price:.0f} ريال\n"
        text += f"📊 **متوسط السوق:** {avg_price:.0f} ريال\n"
        text += f"🎁 **الخصم:** {discount_percent:.0f}% 🔥\n"
        text += f"📍 **المصدر:** {source_name}\n"
        
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("🔗 عرض الإعلان", url=message_link)]
        ])
        
        try:
            await self.app.send_message("me", text, reply_markup=keyboard)
        except Exception as e:
            print(f"❌ فشل إرسال الإشعار: {e}")
    
    async def notify_market_trend(self, 
                                 item_name: str,
                                 trend: str,
                                 change_percent: float):
        """
        إشعار عند تغير ملحوظ في السوق
        """
        if abs(change_percent) < 20:  # أقل من 20% تغيير
            return
        
        emoji = "📈" if trend == "rising" else "📉"
        action = "ارتفع" if trend == "rising" else "انخفض"
        
        text = f"{emoji} **تحديث السوق**\n\n"
        text += f"🎯 **العنصر:** {item_name}\n"
        text += f"📊 **الاتجاه:** {action} بنسبة {abs(change_percent):.0f}%\n"
        
        if trend == "rising":
            text += "\n💡 **نصيحة:** قد يكون وقت جيد للبيع"
        else:
            text += "\n💡 **نصيحة:** قد يكون وقت جيد للشراء"
        
        try:
            await self.app.send_message("me", text)
        except Exception as e:
            print(f"❌ فشل إرسال الإشعار: {e}")
    
    async def notify_learning_request(self, 
                                     crop_path: str,
                                     suggested_item: Optional[str] = None):
        """
        إشعار عند طلب تأكيد على عنصر للتعلم
        """
        text = "🤖 **طلب تأكيد للتعلم**\n\n"
        
        if suggested_item:
            text += f"❓ هل هذا العنصر هو: **{suggested_item}**؟\n"
        else:
            text += "❓ عنصر غير معروف - هل تريد إضافته؟\n"
        
        text += "\nمساعدتك تحسن دقة البوت! 🙏"
        
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("✅ نعم", callback_data=f"learn_yes_{crop_path}"),
                InlineKeyboardButton("❌ لا", callback_data=f"learn_no_{crop_path}")
            ],
            [
                InlineKeyboardButton("➕ عنصر جديد", callback_data=f"learn_new_{crop_path}")
            ]
        ])
        
        try:
            # إرسال الصورة مع الأزرار
            await self.app.send_photo(
                "me",
                crop_path,
                caption=text,
                reply_markup=keyboard
            )
        except Exception as e:
            print(f"❌ فشل إرسال الإشعار: {e}")
    
    async def send_daily_report(self, stats: Dict):
        """
        إرسال تقرير يومي
        """
        text = "📊 **التقرير اليومي**\n\n"
        text += f"📅 **التاريخ:** {stats.get('date', 'اليوم')}\n\n"
        
        text += "**الإحصائيات:**\n"
        text += f"• حسابات مكتشفة: {stats.get('accounts_detected', 0)}\n"
        text += f"• حسابات مبيوعة: {stats.get('accounts_sold', 0)}\n"
        text += f"• عناصر نادرة جديدة: {stats.get('new_rare_items', 0)}\n"
        text += f"• متوسط الأسعار: {stats.get('avg_price', 0):.0f} ريال\n\n"
        
        if 'top_items' in stats:
            text += "🔥 **أكثر العناصر ظهوراً:**\n"
            for item in stats['top_items'][:5]:
                text += f"• {item['name']}: {item['count']} مرة\n"
        
        try:
            await self.app.send_message("me", text)
        except Exception as e:
            print(f"❌ فشل إرسال التقرير: {e}")
    
    def _get_rarity_emoji(self, confidence: float) -> str:
        """الحصول على emoji حسب درجة الندرة"""
        if confidence >= 95:
            return "💎"  # نادر جداً
        elif confidence >= 85:
            return "🔥"  # نادر
        elif confidence >= 75:
            return "⭐"  # غير شائع
        else:
            return "•"   # عادي
    
    async def notify_error(self, error_msg: str):
        """إشعار عند حدوث خطأ مهم"""
        text = f"⚠️ **تنبيه خطأ**\n\n{error_msg}"
        
        try:
            await self.app.send_message("me", text)
        except:
            print(f"❌ فشل إرسال إشعار الخطأ: {error_msg}")
    
    def clear_sent_notifications(self):
        """مسح قائمة الإشعارات المرسلة"""
        self.sent_notifications.clear()