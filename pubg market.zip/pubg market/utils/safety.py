import asyncio
import random
import time
from collections import deque
from datetime import datetime, timedelta
import config

class SafetyManager:
    """إدارة الأمان وحماية الحساب من الحظر"""
    
    def __init__(self):
        # عداد الطلبات
        self.request_times = deque(maxlen=100)
        self.last_request_time = None
        
        # إحصائيات
        self.total_requests = 0
        self.flood_waits = 0
    
    async def random_sleep(self, min_seconds: float = None, max_seconds: float = None):
        """انتظار عشوائي لمحاكاة السلوك البشري"""
        min_s = min_seconds or config.MIN_SLEEP
        max_s = max_seconds or config.MAX_SLEEP
        
        sleep_time = random.uniform(min_s, max_s)
        await asyncio.sleep(sleep_time)
    
    async def check_rate_limit(self):
        """فحص حد السرعة"""
        now = time.time()
        
        # تسجيل الطلب
        self.request_times.append(now)
        self.total_requests += 1
        
        # فحص عدد الطلبات في الدقيقة الأخيرة
        one_minute_ago = now - 60
        recent_requests = sum(1 for t in self.request_times if t > one_minute_ago)
        
        if recent_requests >= config.MAX_MESSAGES_PER_MINUTE:
            # تجاوز الحد - انتظار
            wait_time = 60 - (now - self.request_times[0])
            print(f"⚠️ تجاوز حد السرعة، انتظار {wait_time:.1f}s")
            await asyncio.sleep(wait_time)
            self.flood_waits += 1
    
    async def safe_request(self, func, *args, **kwargs):
        """
        تنفيذ طلب بشكل آمن مع إدارة الأخطاء والـ FloodWait
        """
        max_retries = 3
        retry_count = 0
        
        while retry_count < max_retries:
            try:
                # فحص حد السرعة
                await self.check_rate_limit()
                
                # انتظار عشوائي
                await self.random_sleep()
                
                # تنفيذ الطلب
                result = await func(*args, **kwargs)
                
                self.last_request_time = time.time()
                return result
                
            except Exception as e:
                error_msg = str(e).lower()
                
                # معالجة FloodWait
                if 'flood' in error_msg or 'wait' in error_msg:
                    # استخراج وقت الانتظار
                    import re
                    match = re.search(r'(\d+)', error_msg)
                    wait_time = int(match.group(1)) if match else config.FLOOD_SLEEP_THRESHOLD
                    
                    print(f"⚠️ FloodWait: انتظار {wait_time}s")
                    await asyncio.sleep(wait_time)
                    retry_count += 1
                    self.flood_waits += 1
                    continue
                
                # أخطاء أخرى
                print(f"❌ خطأ: {e}")
                retry_count += 1
                await asyncio.sleep(5 * retry_count)
        
        # فشل بعد كل المحاولات
        print(f"❌ فشل الطلب بعد {max_retries} محاولات")
        return None
    
    def get_stats(self) -> dict:
        """الحصول على إحصائيات الأمان"""
        return {
            'total_requests': self.total_requests,
            'flood_waits': self.flood_waits,
            'recent_requests': len(self.request_times),
            'last_request': self.last_request_time
        }
    
    async def gradual_start(self, total_items: int, process_func):
        """
        بدء تدريجي للمعالجة الجماعية
        لتجنب الحظر عند معالجة عدد كبير من العناصر
        """
        batch_size = 10
        batches = [total_items[i:i+batch_size] for i in range(0, len(total_items), batch_size)]
        
        for batch_idx, batch in enumerate(batches):
            print(f"📦 معالجة الدفعة {batch_idx + 1}/{len(batches)}")
            
            for item in batch:
                await process_func(item)
                await self.random_sleep(2, 4)
            
            # انتظار أطول بين الدفعات
            if batch_idx < len(batches) - 1:
                wait_time = random.uniform(10, 20)
                print(f"⏳ انتظار {wait_time:.1f}s قبل الدفعة التالية...")
                await asyncio.sleep(wait_time)
    
    def is_safe_to_proceed(self) -> bool:
        """فحص إذا كان آمناً المتابعة"""
        if not self.request_times:
            return True
        
        now = time.time()
        one_minute_ago = now - 60
        recent_requests = sum(1 for t in self.request_times if t > one_minute_ago)
        
        return recent_requests < config.MAX_MESSAGES_PER_MINUTE * 0.8  # 80% من الحد
    
    async def wait_if_needed(self):
        """انتظار إذا كان ضرورياً"""
        if not self.is_safe_to_proceed():
            wait_time = random.uniform(30, 60)
            print(f"⏳ وضع الحماية: انتظار {wait_time:.1f}s")
            await asyncio.sleep(wait_time)