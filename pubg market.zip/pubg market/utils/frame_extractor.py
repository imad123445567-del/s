import cv2
import numpy as np
from pathlib import Path
from typing import List, Tuple
import config

class FrameExtractor:
    """استخراج الفريمات الذكية من الفيديو"""
    
    def __init__(self):
        self.frame_interval = config.FRAME_INTERVAL
        self.max_frames = config.MAX_FRAMES_PER_VIDEO
        self.max_duration = config.MAX_VIDEO_DURATION
    
    def extract_frames(self, video_path: str) -> List[np.ndarray]:
        """استخراج فريمات من الفيديو بطريقة ذكية"""
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            raise ValueError(f"لا يمكن فتح الفيديو: {video_path}")
        
        # معلومات الفيديو
        fps = cap.get(cv2.CAP_PROP_FPS)
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration = total_frames / fps if fps > 0 else 0
        
        # تحقق من مدة الفيديو
        if duration > self.max_duration:
            print(f"⚠️ الفيديو طويل جداً ({duration:.1f}s)، سيتم معالجة أول {self.max_duration}s فقط")
            total_frames = int(self.max_duration * fps)
        
        # حساب الفريمات المطلوبة
        frame_step = max(1, int(fps * self.frame_interval))
        
        frames = []
        frame_indices = []
        current_frame = 0
        
        while len(frames) < self.max_frames and current_frame < total_frames:
            cap.set(cv2.CAP_PROP_POS_FRAMES, current_frame)
            ret, frame = cap.read()
            
            if not ret:
                break
            
            # فحص جودة الفريم
            if self._is_good_frame(frame):
                frames.append(frame)
                frame_indices.append(current_frame)
            
            current_frame += frame_step
        
        cap.release()
        
        print(f"✅ تم استخراج {len(frames)} فريم من الفيديو (المدة: {duration:.1f}s)")
        return frames
    
    def _is_good_frame(self, frame: np.ndarray) -> bool:
        """فحص جودة الفريم (وضوح، إضاءة)"""
        # تحويل لـ Grayscale
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        # فحص الوضوح باستخدام Laplacian
        laplacian_var = cv2.Laplacian(gray, cv2.CV_64F).var()
        
        # فحص السطوع
        brightness = np.mean(gray)
        
        # الفريم جيد إذا كان واضح ومضاء بشكل جيد
        is_sharp = laplacian_var > 100  # عتبة الوضوح
        is_well_lit = 30 < brightness < 225  # ليس مظلم جداً أو ساطع جداً
        
        return is_sharp and is_well_lit
    
    def extract_key_frames(self, video_path: str) -> List[np.ndarray]:
        """استخراج الفريمات المفتاحية (التي تحتوي على تغييرات كبيرة)"""
        cap = cv2.VideoCapture(video_path)
        
        frames = []
        prev_frame = None
        threshold = 30.0  # عتبة التغيير
        
        frame_count = 0
        max_frames_to_check = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        
        while frame_count < max_frames_to_check and len(frames) < self.max_frames:
            ret, frame = cap.read()
            if not ret:
                break
            
            # كل N فريم، نفحص التغيير
            if frame_count % int(self.frame_interval * 30) == 0:
                if prev_frame is None:
                    frames.append(frame)
                    prev_frame = frame
                else:
                    # حساب الفرق بين الفريمات
                    diff = cv2.absdiff(
                        cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY),
                        cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
                    )
                    
                    change_ratio = np.sum(diff > 30) / diff.size * 100
                    
                    # إذا كان هناك تغيير كبير
                    if change_ratio > threshold:
                        frames.append(frame)
                        prev_frame = frame
            
            frame_count += 1
        
        cap.release()
        
        print(f"✅ تم استخراج {len(frames)} فريم مفتاحي")
        return frames
    
    def save_frames(self, frames: List[np.ndarray], output_dir: Path, prefix: str = "frame") -> List[Path]:
        """حفظ الفريمات كصور"""
        output_dir.mkdir(parents=True, exist_ok=True)
        
        saved_paths = []
        for i, frame in enumerate(frames):
            output_path = output_dir / f"{prefix}_{i:04d}.jpg"
            cv2.imwrite(str(output_path), frame)
            saved_paths.append(output_path)
        
        return saved_paths
    
    def create_video_summary(self, video_path: str, output_path: str, grid_size: Tuple[int, int] = (3, 3)):
        """إنشاء صورة ملخص من الفيديو (شبكة من الفريمات)"""
        frames = self.extract_frames(video_path)
        
        if not frames:
            return None
        
        rows, cols = grid_size
        num_frames = min(len(frames), rows * cols)
        
        # إعادة حجم الفريمات
        target_size = (400, 300)  # عرض × ارتفاع
        resized_frames = [cv2.resize(f, target_size) for f in frames[:num_frames]]
        
        # ملء الشبكة بالفريمات
        grid = []
        for i in range(rows):
            row_frames = []
            for j in range(cols):
                idx = i * cols + j
                if idx < len(resized_frames):
                    row_frames.append(resized_frames[idx])
                else:
                    # فريم فارغ
                    row_frames.append(np.zeros_like(resized_frames[0]))
            grid.append(np.hstack(row_frames))
        
        summary = np.vstack(grid)
        cv2.imwrite(output_path, summary)
        
        return output_path