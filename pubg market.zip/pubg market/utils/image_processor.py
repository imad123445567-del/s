import cv2
import numpy as np
from pathlib import Path
from typing import List, Tuple, Optional
import config

class ImageProcessor:
    """معالجة وتحسين الصور"""
    
    def __init__(self):
        self.min_item_size = config.MIN_ITEM_SIZE
    
    def preprocess_image(self, image_path: str) -> np.ndarray:
        """تحسين جودة الصورة قبل المعالجة"""
        img = cv2.imread(image_path)
        if img is None:
            raise ValueError(f"لا يمكن قراءة الصورة: {image_path}")
        
        # تحسين السطوع والتباين
        img = self._auto_brightness_contrast(img)
        
        # إزالة الضوضاء
        img = cv2.fastNlMeansDenoisingColored(img, None, 10, 10, 7, 21)
        
        # زيادة الحدة
        img = self._sharpen(img)
        
        return img
    
    def _auto_brightness_contrast(self, img: np.ndarray, clip_hist_percent: float = 1) -> np.ndarray:
        """تحسين تلقائي للسطوع والتباين"""
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # حساب histogram
        hist = cv2.calcHist([gray], [0], None, [256], [0, 256])
        hist_size = len(hist)
        
        # حساب cumulative distribution
        accumulator = []
        accumulator.append(float(hist[0]))
        for index in range(1, hist_size):
            accumulator.append(accumulator[index - 1] + float(hist[index]))
        
        # تحديد القيم العلوية والسفلية
        maximum = accumulator[-1]
        clip_hist_percent *= (maximum / 100.0)
        clip_hist_percent /= 2.0
        
        # حساب الحدود
        minimum_gray = 0
        while accumulator[minimum_gray] < clip_hist_percent:
            minimum_gray += 1
        
        maximum_gray = hist_size - 1
        while accumulator[maximum_gray] >= (maximum - clip_hist_percent):
            maximum_gray -= 1
        
        # التحويل
        alpha = 255 / (maximum_gray - minimum_gray)
        beta = -minimum_gray * alpha
        
        auto_result = cv2.convertScaleAbs(img, alpha=alpha, beta=beta)
        return auto_result
    
    def _sharpen(self, img: np.ndarray) -> np.ndarray:
        """زيادة حدة الصورة"""
        kernel = np.array([[-1, -1, -1],
                          [-1,  9, -1],
                          [-1, -1, -1]])
        return cv2.filter2D(img, -1, kernel)
    
    def detect_objects(self, image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """
        كشف الكائنات (العناصر) في الصورة
        يرجع قائمة بـ bounding boxes
        """
        # تحويل لـ grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # تطبيق threshold
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # إيجاد contours
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        # استخراج bounding boxes
        boxes = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            
            # فلترة الأشياء الصغيرة جداً
            if w >= self.min_item_size and h >= self.min_item_size:
                boxes.append((x, y, w, h))
        
        return boxes
    
    def extract_dominant_colors(self, image: np.ndarray, k: int = 5) -> List[Tuple[int, int, int]]:
        """
        استخراج الألوان السائدة في الصورة
        مفيد للتعرف على العناصر بناءً على ألوانها
        """
        # تحويل لـ RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        
        # تحويل لـ 2D array
        pixels = image_rgb.reshape((-1, 3))
        pixels = np.float32(pixels)
        
        # K-means clustering
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
        _, labels, centers = cv2.kmeans(pixels, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        
        # تحويل لـ integers
        centers = np.uint8(centers)
        
        # ترتيب حسب التكرار
        unique, counts = np.unique(labels, return_counts=True)
        sorted_indices = np.argsort(-counts)
        
        dominant_colors = [tuple(centers[i]) for i in sorted_indices]
        
        return dominant_colors
    
    def compare_images(self, img1: np.ndarray, img2: np.ndarray) -> float:
        """
        مقارنة صورتين وإرجاع نسبة التشابه
        """
        # تحجيم للحجم نفسه
        h, w = img1.shape[:2]
        img2_resized = cv2.resize(img2, (w, h))
        
        # تحويل لـ grayscale
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2_resized, cv2.COLOR_BGR2GRAY)
        
        # حساب SSIM (Structural Similarity Index)
        # بديل بسيط بدون library إضافية
        diff = cv2.absdiff(gray1, gray2)
        similarity = 1 - (np.sum(diff) / (h * w * 255))
        
        return max(0, similarity)
    
    def create_thumbnail(self, image_path: str, output_path: str, max_size: Tuple[int, int] = (200, 200)):
        """إنشاء صورة مصغرة"""
        img = cv2.imread(image_path)
        if img is None:
            return False
        
        h, w = img.shape[:2]
        max_w, max_h = max_size
        
        # حساب النسبة
        ratio = min(max_w / w, max_h / h)
        
        # تحجيم
        new_w = int(w * ratio)
        new_h = int(h * ratio)
        
        thumbnail = cv2.resize(img, (new_w, new_h), interpolation=cv2.INTER_AREA)
        
        # حفظ
        cv2.imwrite(output_path, thumbnail)
        
        return True
    
    def remove_background(self, image: np.ndarray) -> np.ndarray:
        """
        إزالة الخلفية من الصورة (بسيط)
        مفيد لعزل العناصر النادرة
        """
        # تحويل لـ grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # تطبيق GrabCut
        mask = np.zeros(image.shape[:2], np.uint8)
        bgd_model = np.zeros((1, 65), np.float64)
        fgd_model = np.zeros((1, 65), np.float64)
        
        # تحديد منطقة مبدئية (وسط الصورة)
        h, w = image.shape[:2]
        rect = (int(w * 0.1), int(h * 0.1), int(w * 0.8), int(h * 0.8))
        
        try:
            cv2.grabCut(image, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)
            
            # إنشاء mask
            mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
            
            # تطبيق mask
            result = image * mask2[:, :, np.newaxis]
            
            return result
        except:
            # إذا فشل، إرجاع الصورة الأصلية
            return image
    
    def enhance_for_ocr(self, image: np.ndarray) -> np.ndarray:
        """
        تحسين الصورة لقراءة النصوص (OCR)
        مفيد لاستخراج الأسماء والأرقام
        """
        # تحويل لـ grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # تطبيق threshold
        _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # إزالة الضوضاء
        kernel = np.ones((1, 1), np.uint8)
        opening = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, kernel, iterations=1)
        
        return opening
    
    def detect_text_regions(self, image: np.ndarray) -> List[Tuple[int, int, int, int]]:
        """
        كشف مناطق النصوص في الصورة
        مفيد لاستخراج الأسماء والأسعار
        """
        # تحويل لـ grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # MSER (Maximally Stable Extremal Regions)
        mser = cv2.MSER_create()
        regions, _ = mser.detectRegions(gray)
        
        # استخراج bounding boxes
        boxes = []
        for region in regions:
            x, y, w, h = cv2.boundingRect(region)
            
            # فلترة: النصوص عادة أفقية وليست صغيرة جداً
            aspect_ratio = w / h if h > 0 else 0
            if aspect_ratio > 1.5 and w > 20 and h > 10:
                boxes.append((x, y, w, h))
        
        return boxes
    
    def calculate_image_hash(self, image: np.ndarray, hash_size: int = 8) -> str:
        """
        حساب hash للصورة (perceptual hash)
        مفيد للبحث السريع عن صور متشابهة
        """
        # تحويل لـ grayscale وتحجيم
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        resized = cv2.resize(gray, (hash_size + 1, hash_size))
        
        # حساب الفرق
        diff = resized[:, 1:] > resized[:, :-1]
        
        # تحويل لـ string
        hash_str = ''.join(['1' if d else '0' for row in diff for d in row])
        
        return hash_str
    
    def save_with_metadata(self, image: np.ndarray, output_path: str, metadata: dict):
        """
        حفظ صورة مع metadata
        """
        cv2.imwrite(output_path, image)
        
        # حفظ metadata في ملف JSON منفصل
        import json
        metadata_path = Path(output_path).with_suffix('.json')
        with open(metadata_path, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)